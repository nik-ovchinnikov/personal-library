package com.niki.personallibrary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonalLibraryApplicationTests {

	@Test
	void contextLoads() {
	}

}
